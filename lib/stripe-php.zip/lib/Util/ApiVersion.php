<?php

// File generated from our OpenAPI spec

namespace Stripe\Util;

class ApiVersion
{
    const CURRENT = '2025-09-30.clover';
    const CURRENT_MAJOR = 'clover';
}
